---
layout: page
title: About
---

This is a minimal [Learn-Jekyll.js](https://github.com/jan-martinek/learn-jekyll) website.

It is not meant to replace Jekyll — it just mimics some of its functionality. It might be useful for those who do not want to install Ruby & Jekyll on their computer.

To use it, you need to keep a two-level file structure and describe it in `mock/structure.yml`. Learn more about it in its [Github repo](https://github.com/jan-martinek/learn-jekyll).
